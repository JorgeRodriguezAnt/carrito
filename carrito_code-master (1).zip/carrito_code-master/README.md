Ejemplo de carro de compras usando el framework Codeigniter.



