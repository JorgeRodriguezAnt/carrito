<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <!--colocamos los estilos necesarios para la maquetacion-->
        <link rel="stylesheet" type="text/css" href="<?= base_url();?>css/estilos.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/960.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/text.css" media="screen" />
        <link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/reset.css" media="screen" />
        <title><?= $title ?></title>
    </head>
    <body>
      <?php
            //si el carrito contiene productos los mostramos
            if ($carrito = $this->cart->contents()) {
                ?>
                <div class="grid_5" id="contenidoCarrito">
                    <table>
                       <legend>Carrito de la compra</legend>
                        <tr>
                            <th>Nombre</th>
                            <th>Opción</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Eliminar</th>
                        </tr>
                    <?php
                    foreach ($carrito as $item) {
                        ?>
                        <tr>
                            <td><?= ucfirst($item['name']) ?></td>
                            <td>
                                <?php
                                $nombres = array('nombre' => ucfirst($item['name']));
                                $precio = array();
                                $precio = $item['price'];
                                if ($this->cart->has_options($item['rowid'])) {
                                    foreach ($this->cart->product_options($item['rowid']) as $opcion => $value) {
                                        echo $opcion . ": <em>" . $value . "</em>";
                                    }
                                }
                                ?>
                            </td>
                            <td><?= $item['price'] ?></td>
                            <td><?= $item['qty'] ?></td>
                            <!--creamos el enlace para eliminar el producto
                            pulsado pasando el rowid del producto-->
                            <td id="eliminar"><?= anchor('/Catalogo/eliminarProducto/' . $item['rowid'], 'Eliminar') ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                    <tr id="total">
                        <td><strong>Total:</strong></td>
                        <!--mostramos el total del carrito
                        con $this->cart->total()-->
                        <td colspan="1">$<?= $this->cart->total() ?> pesos.</td>
                        <!--creamos un enlace para eliminar el carrito-->
                        <td colspan="4" id="eliminarCarrito"><?= anchor('Catalogo/eliminarCarrito', 'Vaciar carrito')?></td>
                    </tr>
                </table>
                </div>
            <?php
            }
            ?>
          </div>
    	<form>
  		Nombre:<br>
  		<input type="text" name="firstname" placeholder="John" required/><br>
  		Apellidos:<br>
  		<input type="text" name="lastname" placeholder="Doe" required/><br>
      Correo:<br>
      <input type="email" id="email" placeholder="john.doe@uv.cl" required/><br>
      Direccion:<br>
      <input type="adress" name="adress" placeholder="General Cruz #222" required/><br>
      Telefono:<br>
      <input type="tel" name="telefono" placeholder="9-12345678" required/><br>
    </form>
    </body>
    </html>